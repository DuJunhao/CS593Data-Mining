The NULL indicates 0 

the distjaccDirectDebit and distjaccaPayRoll are the final answer of the jaccard distance.

In the JaccardDistance File, there're 8 files for the SASDATA ABCD.